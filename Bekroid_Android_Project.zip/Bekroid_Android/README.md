# Bekroid Android project

Bekroid is the Android app wrapper for the Bekroid HTML interface. It includes JavaScript/local storage support, external internet access, a file chooser, and Android DownloadManager integration.

## Build an APK
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. In Android Studio, choose **Open** and select the extracted `Bekroid_Android` folder.
4. Let Gradle sync. If prompted, install Android SDK Platform 35 and JDK 17.
5. Choose **Build > Build APK(s)**.
6. Find the debug APK at `app/build/outputs/apk/debug/app-debug.apk`.
7. Copy the APK to your Android phone and install it. You may need to allow installation from that file manager.

## Important limits
- This wraps the Bekroid HTML experience as an Android app; it does not turn Bekroid into a full Android operating system.
- Downloaded APK files can be downloaded, but Android will not silently install them. Install APKs only from sources you trust.
- Websites may block embedded browsers. Use the page's **Open outside** option for those sites.
- This ZIP is the Android Studio project, not a prebuilt APK. It must be built with Android Studio/Gradle.

## Build the APK online using GitHub Actions (works from Chrome)
1. On GitHub, create a new repository named `Bekroid`.
2. Upload the contents of this project folder to the repository (the files inside `Bekroid_Android`, not the outer folder itself). Make sure `.github/workflows/build-apk.yml` is included. On mobile, enable **Desktop site** in Chrome if the upload interface is hard to use.
3. Open the repository's **Actions** tab and select **Build Bekroid APK**. If prompted, enable Actions, then press **Run workflow**. A push to the `main` branch also starts a build.
4. Wait for the workflow to finish successfully, open the completed run, and download the `Bekroid-debug-APK` artifact. Extract the downloaded artifact ZIP to get `app-debug.apk`.
5. Open `app-debug.apk` on your Android phone to install it. Android may ask you to allow installs from Chrome or your file manager.

The APK produced this way is a debug build for testing, not a signed Play Store release. Never install APKs from people or websites you do not trust.
